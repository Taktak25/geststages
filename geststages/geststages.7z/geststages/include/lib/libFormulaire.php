<?php

include_once 'include/lib/formulaire/Input.php';
include_once 'include/lib/formulaire/InputDate.php';
include_once 'include/lib/formulaire/InputDateGT.php';
include_once 'include/lib/formulaire/InputHidden.php';
include_once 'include/lib/formulaire/InputNumber.php';
include_once 'include/lib/formulaire/InputSelect.php';
include_once 'include/lib/formulaire/InputSelectBool.php';
include_once 'include/lib/formulaire/InputSelectSQL.php';
include_once 'include/lib/formulaire/InputStringType.php';
include_once 'include/lib/formulaire/InputString.php';
include_once 'include/lib/formulaire/InputTextarea.php';
include_once 'include/lib/formulaire/Fieldset.php';
include_once 'include/lib/formulaire/FieldsetSelectSQL.php';
include_once 'include/lib/formulaire/Formulaire.php';

?>